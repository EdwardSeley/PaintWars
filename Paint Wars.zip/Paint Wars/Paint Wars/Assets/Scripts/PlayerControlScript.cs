﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerControlScript : MonoBehaviour
{
    public float speed = 250f;

    private Rigidbody2D _body;
    private Animator _anim;
    private BoxCollider2D _box;
    private LayerMask environmentLayerMask;
    private float lastHitDistance;
    private Vector3 throwOffset = new Vector3(2, 1, 0);
    private float throwWaitTime = 1f;

    public GameObject paintBall;
    public float jumpForce = 12f;


    void Start()
    {
        _body = GetComponent<Rigidbody2D>();
        _anim = GetComponent<Animator>();
        _box = GetComponent<BoxCollider2D>();
        environmentLayerMask = LayerMask.GetMask("Environment"); 
    }

    private IEnumerator waitAndThrow() {
        yield return new WaitForSeconds(throwWaitTime);
        GameObject projectile = Instantiate(paintBall, transform.position + throwOffset, Quaternion.identity) as GameObject;
        projectile.GetComponent<Rigidbody2D>().AddForce(transform.forward * 10);
    }

    void Update()
    {
        float deltaX = Input.GetAxis("Horizontal") * speed * Time.deltaTime;
        Vector2 movement = new Vector2(deltaX, _body.velocity.y);
        _body.velocity = movement;


        if (Input.GetKeyDown(KeyCode.T))
        {
            StartCoroutine(waitAndThrow());
            _anim.SetBool("isThrowing", true);
        } else
        {
            _anim.SetBool("isThrowing", false);
        }

        RaycastHit2D hit = Physics2D.Raycast(_body.position, Vector2.down, 3f, environmentLayerMask);
        bool grounded = false;

        if (hit) // collided with ground
        {
            if (hit.distance > 1.3) // high off the ground, in the air
            {
                grounded = false;
                _anim.SetBool("inAir", true);
                lastHitDistance = hit.distance;
            }
            else // close to the ground
            {
                grounded = true;
                _anim.SetBool("inAir", false);
            }
        }
        else // No collision with ground, in the air
        {
            _anim.SetBool("inAir", true);
        }
        _body.gravityScale = grounded && deltaX == 0 ? 0 : 1;
        if (Input.GetKeyDown(KeyCode.Space) && grounded)
        {
            _body.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
        _anim.SetFloat("speed", Mathf.Abs(deltaX));
        if (!Mathf.Approximately(deltaX, 0))
        {
            transform.localScale = new Vector3(Mathf.Sign(deltaX), 1, 1);
        }
    }

    void OnDrawGizmos()
    {
        if (_body != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawRay(_body.position, Vector2.down);
        } else
        {
            Gizmos.color = Color.red;
            Gizmos.DrawRay(new Vector2(-5f, 1.19f), Vector2.down);
        }
    }
}
